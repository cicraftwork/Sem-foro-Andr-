<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT');
header('Access-Control-Allow-Headers: Content-Type');

// Archivo donde se guardará el estado
$estadoFile = 'estado_catalogo.json';

// Función para leer el estado actual
function leerEstado($archivo) {
    if (!file_exists($archivo)) {
        return [
            'ocupado' => false,
            'usuario' => null,
            'timestamp' => null,
            'cola_solicitudes' => [],
            'visitantes_online' => [],
            'asignacion_pendiente' => [
                'usuario' => null,
                'timestamp_limite' => null,
                'activa' => false
            ],
            'ultima_actualizacion' => date('Y-m-d H:i:s')
        ];
    }
    
    $contenido = file_get_contents($archivo);
    $estado = json_decode($contenido, true);
    
    // Migrar estructura antigua si es necesario
    if (!isset($estado['cola_solicitudes'])) {
        $estado['cola_solicitudes'] = [];
    }
    if (!isset($estado['visitantes_online'])) {
        $estado['visitantes_online'] = [];
    }
    if (!isset($estado['asignacion_pendiente'])) {
        $estado['asignacion_pendiente'] = [
            'usuario' => null,
            'timestamp_limite' => null,
            'activa' => false
        ];
    }
    
    return $estado;
}

// Función para guardar el estado
function guardarEstado($archivo, $estado) {
    $estado['ultima_actualizacion'] = date('Y-m-d H:i:s');
    return file_put_contents($archivo, json_encode($estado, JSON_PRETTY_PRINT));
}

// Función para limpiar visitantes offline
function limpiarVisitantesOffline($estado) {
    $tiempoLimite = time() - 30; // 30 segundos sin heartbeat = offline
    
    foreach ($estado['visitantes_online'] as $index => $visitante) {
        if (isset($visitante['ultimo_heartbeat']) && $visitante['ultimo_heartbeat'] < $tiempoLimite) {
            // Remover de visitantes online
            unset($estado['visitantes_online'][$index]);
            
            // Remover de cola de solicitudes si estaba
            foreach ($estado['cola_solicitudes'] as $i => $solicitud) {
                if ($solicitud['usuario'] === $visitante['usuario']) {
                    unset($estado['cola_solicitudes'][$i]);
                    break;
                }
            }
        }
    }
    
    // Reindexar arrays
    $estado['visitantes_online'] = array_values($estado['visitantes_online']);
    $estado['cola_solicitudes'] = array_values($estado['cola_solicitudes']);
    
    return $estado;
}

// Función para procesar asignación pendiente
function procesarAsignacionPendiente($estado) {
    if ($estado['asignacion_pendiente']['activa']) {
        $ahora = time();
        $limite = strtotime($estado['asignacion_pendiente']['timestamp_limite']);
        
        if ($ahora > $limite) {
            // Timeout, pasar al siguiente o liberar
            $usuarioTimeout = $estado['asignacion_pendiente']['usuario'];
            
            // Remover de cola al usuario que hizo timeout
            foreach ($estado['cola_solicitudes'] as $i => $solicitud) {
                if ($solicitud['usuario'] === $usuarioTimeout) {
                    unset($estado['cola_solicitudes'][$i]);
                    break;
                }
            }
            $estado['cola_solicitudes'] = array_values($estado['cola_solicitudes']);
            
            // Asignar al siguiente o liberar
            if (count($estado['cola_solicitudes']) > 0) {
                $siguiente = $estado['cola_solicitudes'][0];
                $estado['asignacion_pendiente'] = [
                    'usuario' => $siguiente['usuario'],
                    'timestamp_limite' => date('Y-m-d H:i:s', time() + 180), // 3 minutos
                    'activa' => true
                ];
            } else {
                $estado['asignacion_pendiente'] = [
                    'usuario' => null,
                    'timestamp_limite' => null,
                    'activa' => false
                ];
            }
        }
    }
    
    return $estado;
}

// Obtener método HTTP
$metodo = $_SERVER['REQUEST_METHOD'];

switch ($metodo) {
    case 'GET':
        // Devolver estado actual
        $estado = leerEstado($estadoFile);
        $estado = limpiarVisitantesOffline($estado);
        $estado = procesarAsignacionPendiente($estado);
        guardarEstado($estadoFile, $estado);
        
        echo json_encode([
            'success' => true,
            'data' => $estado
        ]);
        break;
        
    case 'POST':
        // Recibir datos del frontend
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode([
                'success' => false,
                'message' => 'Datos inválidos'
            ]);
            break;
        }
        
        $accion = $input['accion'] ?? '';
        
        switch ($accion) {
            case 'tomar_control':
                $usuario = $input['usuario'] ?? '';
                if (empty($usuario)) {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Usuario requerido'
                    ]);
                    break;
                }
                
                $estadoActual = leerEstado($estadoFile);
                $estadoActual = limpiarVisitantesOffline($estadoActual);
                
                if ($estadoActual['ocupado']) {
                    echo json_encode([
                        'success' => false,
                        'message' => 'El catálogo ya está ocupado por ' . $estadoActual['usuario']
                    ]);
                } else {
                    $estadoActual['ocupado'] = true;
                    $estadoActual['usuario'] = $usuario;
                    $estadoActual['timestamp'] = date('d/m H:i');
                    
                    // Limpiar cola de solicitudes y asignación pendiente
                    $estadoActual['cola_solicitudes'] = [];
                    $estadoActual['asignacion_pendiente'] = [
                        'usuario' => null,
                        'timestamp_limite' => null,
                        'activa' => false
                    ];
                    
                    if (guardarEstado($estadoFile, $estadoActual)) {
                        echo json_encode([
                            'success' => true,
                            'message' => $usuario . ' ha tomado control del catálogo',
                            'data' => $estadoActual
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Error al guardar el estado'
                        ]);
                    }
                }
                break;
                
            case 'liberar_control':
                $estadoActual = leerEstado($estadoFile);
                
                if (!$estadoActual['ocupado']) {
                    echo json_encode([
                        'success' => false,
                        'message' => 'El catálogo ya está libre'
                    ]);
                } else {
                    $usuarioAnterior = $estadoActual['usuario'];
                    $estadoActual['ocupado'] = false;
                    $estadoActual['usuario'] = null;
                    $estadoActual['timestamp'] = null;
                    
                    // Activar asignación pendiente si hay cola
                    if (count($estadoActual['cola_solicitudes']) > 0) {
                        $siguiente = $estadoActual['cola_solicitudes'][0];
                        $estadoActual['asignacion_pendiente'] = [
                            'usuario' => $siguiente['usuario'],
                            'timestamp_limite' => date('Y-m-d H:i:s', time() + 180), // 3 minutos
                            'activa' => true
                        ];
                    }
                    
                    if (guardarEstado($estadoFile, $estadoActual)) {
                        echo json_encode([
                            'success' => true,
                            'message' => $usuarioAnterior . ' ha liberado el catálogo',
                            'data' => $estadoActual
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Error al liberar el catálogo'
                        ]);
                    }
                }
                break;
                
            case 'solicitar_uso':
                $usuario = $input['usuario'] ?? '';
                if (empty($usuario)) {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Usuario requerido'
                    ]);
                    break;
                }
                
                $estadoActual = leerEstado($estadoFile);
                $estadoActual = limpiarVisitantesOffline($estadoActual);
                
                // Verificar si ya está en cola
                $yaEnCola = false;
                foreach ($estadoActual['cola_solicitudes'] as $solicitud) {
                    if ($solicitud['usuario'] === $usuario) {
                        $yaEnCola = true;
                        break;
                    }
                }
                
                if ($yaEnCola) {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Ya estás en la cola de solicitudes'
                    ]);
                } else {
                    $estadoActual['cola_solicitudes'][] = [
                        'usuario' => $usuario,
                        'timestamp' => date('d/m H:i'),
                        'activo' => true
                    ];
                    
                    if (guardarEstado($estadoFile, $estadoActual)) {
                        echo json_encode([
                            'success' => true,
                            'message' => $usuario . ' agregado a la cola de solicitudes',
                            'data' => $estadoActual
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Error al procesar solicitud'
                        ]);
                    }
                }
                break;
                
            case 'cancelar_solicitud':
                $usuario = $input['usuario'] ?? '';
                if (empty($usuario)) {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Usuario requerido'
                    ]);
                    break;
                }
                
                $estadoActual = leerEstado($estadoFile);
                
                foreach ($estadoActual['cola_solicitudes'] as $i => $solicitud) {
                    if ($solicitud['usuario'] === $usuario) {
                        unset($estadoActual['cola_solicitudes'][$i]);
                        break;
                    }
                }
                $estadoActual['cola_solicitudes'] = array_values($estadoActual['cola_solicitudes']);
                
                if (guardarEstado($estadoFile, $estadoActual)) {
                    echo json_encode([
                        'success' => true,
                        'message' => $usuario . ' removido de la cola',
                        'data' => $estadoActual
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Error al cancelar solicitud'
                    ]);
                }
                break;
                
            case 'heartbeat':
                $usuario = $input['usuario'] ?? '';
                if (empty($usuario)) {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Usuario requerido'
                    ]);
                    break;
                }
                
                $estadoActual = leerEstado($estadoFile);
                $estadoActual = limpiarVisitantesOffline($estadoActual);
                
                // Actualizar o agregar visitante
                $encontrado = false;
                foreach ($estadoActual['visitantes_online'] as &$visitante) {
                    if ($visitante['usuario'] === $usuario) {
                        $visitante['ultimo_heartbeat'] = time();
                        $encontrado = true;
                        break;
                    }
                }
                
                if (!$encontrado) {
                    $estadoActual['visitantes_online'][] = [
                        'usuario' => $usuario,
                        'ultimo_heartbeat' => time(),
                        'timestamp_conexion' => date('d/m H:i')
                    ];
                }
                
                guardarEstado($estadoFile, $estadoActual);
                
                echo json_encode([
                    'success' => true,
                    'data' => $estadoActual
                ]);
                break;
                
            case 'confirmar_asignacion':
                $usuario = $input['usuario'] ?? '';
                if (empty($usuario)) {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Usuario requerido'
                    ]);
                    break;
                }
                
                $estadoActual = leerEstado($estadoFile);
                
                if ($estadoActual['asignacion_pendiente']['activa'] && 
                    $estadoActual['asignacion_pendiente']['usuario'] === $usuario) {
                    
                    // Tomar control
                    $estadoActual['ocupado'] = true;
                    $estadoActual['usuario'] = $usuario;
                    $estadoActual['timestamp'] = date('d/m H:i');
                    
                    // Limpiar asignación y cola
                    $estadoActual['asignacion_pendiente'] = [
                        'usuario' => null,
                        'timestamp_limite' => null,
                        'activa' => false
                    ];
                    $estadoActual['cola_solicitudes'] = [];
                    
                    if (guardarEstado($estadoFile, $estadoActual)) {
                        echo json_encode([
                            'success' => true,
                            'message' => $usuario . ' confirmó asignación y tomó control',
                            'data' => $estadoActual
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Error al confirmar asignación'
                        ]);
                    }
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => 'No tienes una asignación pendiente válida'
                    ]);
                }
                break;
                
            default:
                echo json_encode([
                    'success' => false,
                    'message' => 'Acción no válida'
                ]);
        }
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'message' => 'Método no permitido'
        ]);
}
?>